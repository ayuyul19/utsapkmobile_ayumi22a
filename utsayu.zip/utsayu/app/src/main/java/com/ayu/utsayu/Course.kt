package com.ayu.utsayu

data class Course(
    val title :String,
    val path : String,
    val image:String
)
